import bcrypt from 'bcryptjs';
import {
  db
} from './connection.js';

const seed = db.transaction(() => {
  const email = 'admin@stockwise.local';
  if (db.prepare('SELECT id FROM users WHERE email = ?').get(email)) return;
  const user = db.prepare('INSERT INTO users (email, name, password_hash) VALUES (?, ?, ?)').run(email, 'Demo Administrator', bcrypt.hashSync('Admin@12345', 12));
  const org = db.prepare('INSERT INTO organizations (name, currency) VALUES (?, ?)').run('Northstar Goods', 'INR');
  const roles = ['Owner', 'Admin', 'Inventory Manager', 'Warehouse Manager', 'Procurement', 'Finance', 'Sales', 'Staff', 'Viewer'];
  const roleIds = new Map();
  for (const role of roles) roleIds.set(role, db.prepare('INSERT INTO roles (name) VALUES (?)').run(role).lastInsertRowid);
  const permissionKeys = ['products.read', 'products.create', 'products.update', 'products.delete', 'inventory.read', 'inventory.receive', 'inventory.issue', 'inventory.transfer', 'inventory.adjust', 'warehouse.read', 'warehouse.manage', 'purchases.read', 'purchases.create', 'purchases.approve', 'sales.read', 'sales.create', 'invoice.read', 'invoice.create', 'reports.read', 'users.manage', 'settings.manage'];
  const permissionIds = new Map();
  for (const key of permissionKeys) permissionIds.set(key, db.prepare('INSERT INTO permissions (key) VALUES (?)').run(key).lastInsertRowid);
  const grants = {
    Owner: permissionKeys,
    Admin: permissionKeys,
    'Inventory Manager': ['products.read','products.create','products.update','inventory.read','inventory.receive','inventory.issue','inventory.transfer','inventory.adjust','warehouse.read','reports.read'],
    'Warehouse Manager': ['products.read','inventory.read','inventory.receive','inventory.issue','inventory.transfer','inventory.adjust','warehouse.read','warehouse.manage'],
    Procurement: ['products.read','inventory.read','warehouse.read','purchases.read','purchases.create','purchases.approve'],
    Finance: ['products.read','reports.read','invoice.read','invoice.create'],
    Sales: ['products.read','inventory.read','sales.read','sales.create','invoice.read','invoice.create'],
    Staff: ['products.read','inventory.read','warehouse.read'],
    Viewer: ['products.read','inventory.read','warehouse.read','purchases.read','sales.read','invoice.read','reports.read']
  };
  for (const [roleName, permissions] of Object.entries(grants)) {
    for (const key of permissions) db.prepare('INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)').run(roleIds.get(roleName), permissionIds.get(key));
  }
  db.prepare('INSERT INTO memberships (user_id, organization_id, role_id) VALUES (?, ?, ?)').run(user.lastInsertRowid, org.lastInsertRowid, roleIds.get('Owner'));
  const category = db.prepare('INSERT INTO categories (organization_id, name) VALUES (?, ?)').run(org.lastInsertRowid, 'Beverages');
  const supplier = db.prepare('INSERT INTO suppliers (organization_id, name, email, phone) VALUES (?, ?, ?, ?)').run(org.lastInsertRowid, 'Evergreen Wholesale', 'orders@evergreen.example', '+91 80 5550 1200');
  const wh = db.prepare('INSERT INTO warehouses (organization_id, name, code, address) VALUES (?, ?, ?, ?)').run(org.lastInsertRowid, 'Central warehouse', 'WH-01', 'Bengaluru');
  const products = [
    ['BEV-001', 'Arabica coffee beans', 420, 690, 18, 36, 48],
    ['BEV-002', 'Oat milk, 1L', 96, 155, 24, 48, 16],
    ['BEV-003', 'Cold brew concentrate', 210, 360, 12, 24, 8],
    ['BEV-004', 'Ceramic pour-over set', 580, 990, 8, 16, 31],
    ['BEV-005', 'Reusable filter pack', 145, 249, 10, 20, 0],
    ['BEV-006', 'Cocoa powder, 500g', 180, 310, 12, 24, 62]
  ];
  const insertProduct = db.prepare('INSERT INTO products (organization_id, category_id, supplier_id, sku, name, cost_price, selling_price, reorder_point, reorder_quantity) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
  const insertInventory = db.prepare('INSERT INTO inventory (organization_id, product_id, warehouse_id, quantity) VALUES (?, ?, ?, ?)');
  for (const [sku, name, cost, price, reorder, reorderQty, qty] of products) {
    const product = insertProduct.run(org.lastInsertRowid, category.lastInsertRowid, supplier.lastInsertRowid, sku, name, cost, price, reorder, reorderQty);
    insertInventory.run(org.lastInsertRowid, product.lastInsertRowid, wh.lastInsertRowid, qty);
  }
  db.prepare('INSERT INTO notifications (organization_id, title, message, type) VALUES (?, ?, ?, ?)').run(org.lastInsertRowid, 'Stock needs attention', 'Reusable filter pack is out of stock.', 'critical');
  db.prepare('INSERT INTO audit_logs (organization_id, user_id, action, entity, details) VALUES (?, ?, ?, ?, ?)').run(org.lastInsertRowid, user.lastInsertRowid, 'seeded_demo', 'organization', '{"source":"development seed"}');
});
seed();
console.log('Demo data is ready. Development login: admin@stockwise.local / Admin@12345');
