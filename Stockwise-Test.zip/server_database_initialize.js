import './connection.js';
console.log('Stockwise database schema is ready.');
